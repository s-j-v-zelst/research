This folder contains all files related to the experimental results of the 2017 ATAED paper entitled "Tuning Alignment Computation; An Experimental Evaluation".
Here, we explain the folder structure:

population_definitions
	Input files needed to generate random process models.
	The files specify the probabilities of certain constructs, i.e. choice, parallelism etc., in the models generated.

rapidprom_source
	Contains a file (README.txt) explaining how to obtain an exact copy of the source code used within experiments.

results
	Contains the raw and aggregated results of the experiments.
	The .log files contain the raw results.
	Note that for the ILP-based heuristic more parameters are defined and hence we have more results.
	The folder contains a lot of .csv files containing aggregated results related to different charts in the paper.
	the R scripts contain the scripts used to generate the charts in the paper.
	the plots folder contains the corresponding generated charts.

scientific_workflow
	Contains the scientific workflow used in RapidProM.
	You can simply import the workflow in RapidMiner (given that the correct custom version of RapidProM is installed, see folder: rapidprom_source)


