The experiments performed for the 2017 ATAED paper, entitled "Tuning Alignment Computation; An Experimental Evaluation", are performed using a custom build version of RapidProM.
The git repository of RapidProM can be downloaded at: https://github.com/rapidprom/rapidprom-source
Please checkout branch "2017_ataed_alignments_merge" (shaID: 54201695f9dfaae7e92521fcb90b9b01accf0c8e)

You can import the source code in eclipse as a gradle project.
Subsequently, to generate a jar which can be loaded as a plugin in RapidMiner (given that you run RM with a developer license, or, having some other form of elevated license), run the "installExtension" gradle task.
You can also build rapidminer from source.
Checkout the gradle project from: http://gihub.com/rapidprom/rapidminer-studio (rapidprom branch).
To run rapidminer from source run the "GuiLauncher.java" file (com.rapidminer.GuiLauncher).

Note that a custom collection of libraries is needed for this RapidProM release, which can be found at: http://github.com/rapidprom/rapidprom-libraries.
Again this concerns branch "2017_ataed_alignments_merge".
You do not need to checkout this branch however in order to compile the custom release of RapidProM.