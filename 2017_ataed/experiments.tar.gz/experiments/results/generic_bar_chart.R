library(ggplot2)
library(extrafont)
library(reshape2)
loadfonts(device="win")

data_path <- "E:/svn/private/papers/2017_alignments_parameters/results/run_1/"
file_name <- "ilp_vs_naive_computation_time_max_35_par.csv"
data_file <- paste(data_path, file_name, sep="")

output_path <- "E:/svn/private/papers/2017_alignments_parameters/results/run_1/plots/"
output_file_name <- "ilp_vs_naive_computation_time_max_35_par"
output_file <- paste(output_path, output_file_name, sep="")

data <- read.table(file=data_file, header=TRUE, sep=";")

df <- as.data.frame(data)

#transpose data
dfm <- melt(df[,c('parallelism','noise','naive','ilp')],id.vars = c(1,2))

setEPS()
trellis.device("postscript", color=TRUE)
postscript(paste(output_file,".eps", sep=""),family = "LM Roman 10", width=10, height = 5)
ggplot(dfm,aes(interaction(noise, parallelism),y = value)) + 
  theme_bw() +
  geom_bar(aes(fill = variable),stat = "identity",position = "dodge") +
  facet_wrap(~parallelism, scales = "free_x", ncol = 4) +
  scale_x_discrete(labels=unique(dfm$noise)) +
  scale_fill_manual(values=c("#222222","#DDDDDD"), 
                         name="Heuristic",
                         labels=c("Naive", "ILP")) +
  labs(x="% Noise", y="Avg. Computation Time (ms.)") +
  theme(strip.placement = "outside",
        axis.text.x = element_text(angle = 45))
dev.off()