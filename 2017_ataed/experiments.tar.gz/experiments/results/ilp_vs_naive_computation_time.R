library(ggplot2)
library(extrafont)
library(reshape2)
loadfonts(device="win")

data_path <- "E:/svn/private/papers/2017_alignments_parameters/results/run_1/"
file_name <- "ilp_vs_naive_computation_time.csv"
data_file <- paste(data_path, file_name, sep="")

output_path <- "E:/svn/private/papers/2017_alignments_parameters/results/run_1/plots/"
output_file_name <- "ilp_vs_naive_computation_time"
output_file <- paste(output_path, output_file_name, sep="")

data <- read.table(file=data_file, header=TRUE, sep="\t")

df <- as.data.frame(data)

#transpose data
dfm <- melt(df[,c('parallelism','noise','naive','ilp')],id.vars = c(1,2))

ggplot(dfm,aes(interaction(noise, parallelism),y = value)) + 
  geom_bar(aes(fill = variable),stat = "identity",position = "dodge") +
  facet_wrap(~parallelism, scales = "free_x") +
  scale_x_discrete(labels=unique(dfm$noise)) +
  theme_bw() +
  theme(panel.spacing = unit(0, "lines"), 
        strip.background = element_blank(),
        strip.placement = "outside",
        axis.text.x = element_text(angle = 45))