Simply import the workflow in RapidMiner (with RapidProM installed).
Make sure that the population loop refers to the populations folder provided in this archive.