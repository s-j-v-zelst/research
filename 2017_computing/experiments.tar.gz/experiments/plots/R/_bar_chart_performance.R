library(extrafont)
library(ggplot2)
library(lattice)
library(reshape2)
library(scales)
loadfonts(device="win")

#ltheme <- canonical.theme(color = TRUE)      ## in-built B&W theme  
#ltheme$strip.background$col <- "transparent" ## change strip bg  
#lattice.options(default.theme = ltheme)      ## set as default  

data_path <- "E:/svn/private/papers/2015_ilp_journal/_non_versioned/experiments/a22/"
file_name <- "a22_run_time_avg_formatted"
data_file <- paste(data_path,file_name, ".csv", sep="")

output_path <- "E:/svn/private/papers/2015_ilp_journal/trunk/plots/R/"
output_file_name <- "a22_run_time"
output_file <- paste(output_path, output_file_name, sep="")

data <- read.table(file=data_file, header=TRUE, sep="\t")

data_melt <- melt(data, id.vars=c("noise", "threshold"))

setEPS()
postscript(paste(output_file,".eps", sep=""),family = "LM Roman 10", colormodel="rgb", width=10,height=5)
ggplot(data_melt, aes(x=threshold,y=value,fill=factor(variable))) + 
  geom_bar(stat="identity",position="dodge")+   
  facet_wrap(~noise) +
  scale_fill_grey(start = 0, end = .9, name="Filter", labels=c("IMi", "Sequence Encoding", "Automaton")) +
  scale_y_continuous(trans=log10_trans())+
  theme_bw()+
  xlab("Threshold")+
  ylab("Computation Time (ms.)")
dev.off()




# OLD CHART:


#noise <- data$noise
#thres <- data$threshold
#im <- data$im
#ilp <- data$ilp
#automaton <- data$automaton


#df <- data.frame(Noise = noise, Threshold= thres, IMi = im, Sequence= ilp, Automaton = automaton)


#setEPS()
#postscript(paste(output_file,".eps", sep=""),family = "LM Roman 10", colormodel="rgb")
#barchart(Threshold ~ Sequence + IMi + Automaton | Noise, 
#         data=df,
#         layout=c(5,1),
#         scales=list(
#           y=list(labels=c("0", "0.25", "0.5", "0.75", "1"), draw=TRUE),
#           x=list(rot=90, tck=1, log=10)
#         ),
#         ylab = list(label = "Threshold", fontsize=12, fontfamily="LM Roman 10"),
#         xlab = list(label = "Computation Time (ms.)", fontsize=12, fontfamily="LM Roman 10"),
#         auto.key = list(space="top", columns=1, 
#                         points=FALSE, rectangles=TRUE, text=c("Sequence Encoding", "IMi", "Automaton"), cex=2, color=TRUE)
#         
#)

#dev.off()
