library(lattice)
library(extrafont)
loadfonts(device="win")

data_path <- "E:/svn/private/papers/2015_ilp_journal/_non_versioned/experiments/sepsis"
file_name <- "experiment_seq_v1_ais_hadoop_4.csv"
data_file <- paste(data_path,"/", file_name, sep="")

output_path <- "E:/svn/private/papers/2015_ilp_journal/trunk/plots/R/"
output_file_name <- "sepsis"
output_file <- paste(output_path, output_file_name, sep="")

data <- read.table(file=data_file, header=TRUE, sep="\t")

thres <- data$filter_threshold
arcs <- data$num_arcs


df <- data.frame(Threshold=thres, Arcs=arcs)

font_cex <- 2

#setEPS()
trellis.device("postscript", color=TRUE)
postscript(paste(output_file,"_complexity.eps", sep=""),family = "LM Roman 10")
xyplot(Arcs ~ Threshold, 
       data=df, 
       type="o",  
       auto.key = list(space = "right", points = TRUE, lines = FALSE),
       ylab = list(label="Number of Arcs", fontsize=25, fontfamily="LM Roman 10"),
       xlab=list(label="Threshold", fontsize=25,fontfamily="LM Roman 10"),
       scales=list(cex=font_cex, fontfamily="LM Roman 10"))
dev.off()
