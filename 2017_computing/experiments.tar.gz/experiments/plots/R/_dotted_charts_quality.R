library(lattice)
library(extrafont)
loadfonts(device="win")

data_path <- "E:/svn/private/papers/2015_ilp_journal/_non_versioned/experiments/road_fines"
file_name <- "experiment_seq_v1_ais_hadoop_4.csv"
data_file <- paste(data_path,"/", file_name, sep="")

output_path <- "E:/svn/private/papers/2015_ilp_journal/trunk/plots/R/"
output_file_name <- "road_fines"
output_file <- paste(output_path, output_file_name, sep="")

data <- read.table(file=data_file, header=TRUE, sep="\t")

thres <- data$filter_threshold
fitness <- data$fitness
precision <- data$precision


df <- data.frame(Threshold=thres, Fitness=fitness, Precision = precision)

font_cex <- 2

#setEPS()
trellis.device("postscript", color=TRUE)
postscript(paste(output_file,"_quality.eps", sep=""),family = "LM Roman 10")
xyplot(Fitness + Precision ~ Threshold, 
       data=df,
       type="o",  
       auto.key = list(space = "right", points = TRUE, lines = FALSE, cex=2),
       ylab = list(label="Replay-Fitness/Precision", fontsize=25, fontfamily="LM Roman 10"),
       xlab=list(label="Threshold", fontsize=25,fontfamily="LM Roman 10"),
       scales=list(cex=font_cex, fontfamily="LM Roman 10"))
dev.off()
