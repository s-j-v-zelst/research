library(lattice)
library(extrafont)
loadfonts(device="win")

theme.novpadding <- list(
  layout.heights = list(
    top.padding = 0,
    main.key.padding = 0,
    key.axis.padding = 0,
    axis.xlab.padding = 0,
    xlab.key.padding = 0,
    key.sub.padding = 0,
    bottom.padding = 0
  ),
  layout.widths = list(
    left.padding = 0,
    key.ylab.padding = 0,
    ylab.axis.padding = 0,
    axis.key.padding = 0,
    right.padding = 0
  ),
  axis.line=list(col="transparent"), 
  clip=list(panel=FALSE)
)



data_path = "E:/svn/private/papers/2015_ilp_journal/_non_versioned/experiments/"
exp_logs <- c("a12", "a22", "a32", "a42")
approaches <- c("ilp", "im","filter_automata")
measures <- c("precision", "fitness")
measures_pretty_print <- c("Precision", "Fitness")
output_path = "E:/svn/private/papers/2015_ilp_journal/trunk/plots/R/"

for (exp_log in exp_logs) {
  for (approach in approaches) {
    data_file <- paste(data_path, exp_log, "/experiment_v1_",approach,".csv", sep="")
    if (file.exists(data_file)) {
      for (measure in measures) {
        measure_pretty = measures_pretty_print[match(measure,measures)]
        
        data <- read.table(file=data_file, header=TRUE, sep="\t")
      
        noise <- data$noise_level
        thres <- data$filter_threshold
        measurement <- data[,measure]
      
      
        surface.df <- data.frame(x=noise, y=thres, z=measurement)
        
        output_file <- paste(output_path, exp_log,"_",approach,"_",measure, sep="")
        #pdf(paste(output_file,".pdf", sep=""))
        #png(paste(output_file,".png", sep=""))
        setEPS()
        postscript(paste(output_file,".eps", sep=""),family = "LM Roman 10")
        print(
          wireframe(z ~ x*y, 
            data = surface.df,
            xlab = list("Noise Level (%)", rot = -50, fontsize=25, fontfamily="LM Roman 10"),
            ylab = list("Filter Threshold", rot = 17.5, fontsize=25, fontfamily="LM Roman 10"),
            zlab = list(measure_pretty, rot = 90, fontsize=25, fontfamily="LM Roman 10"),
            zlim = c(0,1),
            main = "",
            scales = list(arrows = FALSE, cex=1.75, fontfamily="LM Roman 10"),
            drape = TRUE,
            colorkey = list(height=0.65),
            screen = list(z = -60, x = -60),
            aspect = c(61/87, 0.4),
            light.source = c(10,0,10),
            col.regions = colorRampPalette(c("yellow", "red"))(100),
            at = seq(0,1.01,length=100),
            par.settings = theme.novpadding
          )
        )
        dev.off()
      }
    }
  }
}




